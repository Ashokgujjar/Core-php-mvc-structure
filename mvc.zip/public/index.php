<?php

require_once __DIR__.'/../app/init.php';


$app = new App;